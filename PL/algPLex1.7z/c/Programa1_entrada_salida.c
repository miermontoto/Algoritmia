#include <stdio.h>

int main (){
int x, y;
printf ("Introduzca un entero: ");
scanf ("%d", &x);
printf ("Introduzca un segundo entero: ");
scanf ("%d", &y);
printf ("\nLos valores introducidos son: %d y %d\n", x, y);
return 0;
}
