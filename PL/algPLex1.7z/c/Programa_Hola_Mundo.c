#include <stdio.h>

int main ()
{
printf ("HOLA MUNDO");
return 0;
}
