#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

# define NUM_TALLAS 10
# define REPEITERA 100000
# define REPERECUR 10000
# define REPEBUSCA 100 // !!! --- se bajan las repeticiones de la busca a 10 por problemas de jubilación.

// Prototipos de funciones
int    rellena(int **, int);
int   SumaIter(int **, int);
int  SumaRecur(int **, int);
bool     Busca(int **, int, int);
int rellenaNum(int **, int, int);
int printMatriz(int **, int);

// Programa principal
int main()
{
 int i, j;
 clock_t tiempo_ini1, tiempo_ini2, tiempo_fin1, tiempo_fin2;
 int talla[NUM_TALLAS]={1000,2000,3000,4000,5000,6000,7000,8000,9000,10000};
 int **Matriz=NULL, sumaiter=0, sumarecur=0;

 printf("\n\n   SESION 2 DE PRACTICAS DE ANALISIS DE ALGORITMOS  \n\n");
 printf("Tiempo empleado:\n\n\n");

 printf("\t\tTalla\t\tTiempo Mejor caso\tTiempo Peor caso\n");
 printf("\t\t-----\t\t----------------\t----------------\n");

 printf("\t\tTalla\t\tTiempo Iterativo\tTiempo Recursivo\n");
 printf("\t\t-----\t\t----------------\t----------------\n");

 for (i=0;i<NUM_TALLAS;i++) {

    // se reserva el espacio para las files (talla[i] cantidad de filas).
    Matriz = (int**) malloc (talla[i] * sizeof(int *));

    // se reserva el espacio para las columnas por cada fila (talla[i] cantidad de columnas)
    for(int a = 0; a < talla[i]; a++) Matriz[a] = (int *) malloc (talla[i] * sizeof(int));
    // me he pasado 20 minutos buscando este ^ fallo
    // tenía una 'i' puesta, en vez de la a, por lo que no se reservaba el espacio de las columnas.

    // rellena(Matriz,talla[i]); // se rellena la matriz de valores enteros.
    rellenaNum(Matriz, talla[i], 23);
    //printMatriz(Matriz, talla[i]);

    // FRAGMENTO DE CODIGO PARA ANALIZAR LA BUSQUEDA EN LA MATRIZ
    /*
    tiempo_ini1=clock();
    for (j=1;j<=REPEBUSCA;j++)
      Busca(Matriz, talla[i], 23); // se busca por 23 porque se ha rellenado la matriz de 23's (mejor caso)
    tiempo_fin1=clock();

    tiempo_ini2=clock();
    for (j=1;j<=REPEBUSCA;j++)
      Busca(Matriz, talla[i], 22); // con la matriz rellena de 23's, no debería encontrarse ningún 22. (peor caso)
    tiempo_fin2=clock();

    printf("\t\t%d\t\t%f", talla[i],(tiempo_fin1-tiempo_ini1) /(double)CLOCKS_PER_SEC / REPEBUSCA);
    printf("\t\t%f\n",              (tiempo_fin2-tiempo_ini2) /(double)CLOCKS_PER_SEC / REPEBUSCA);

    // FRAGMENTO DE CODIGO PARA ANALIZAR LA SUMA DE LOS ELEMENTOS DE LA DIAGONAL DE LA MATRIZ
    */
    tiempo_ini1=clock();
    for (j=1;j<=REPEITERA;j++)
      sumaiter = SumaIter(Matriz, talla[i]);
    tiempo_fin1=clock();

    tiempo_ini2=clock();
    for (j=1;j<=REPERECUR;j++)
      sumarecur = SumaRecur(Matriz, talla[i]) - Matriz[0][0];
    tiempo_fin2=clock();

    if (sumarecur != sumaiter) { printf("%d vs. %d, inconsistencia en las sumas", sumaiter, sumarecur); return -1; }

    printf("\t\t%d\t\t%f", talla[i],(tiempo_fin1-tiempo_ini1) /(double)CLOCKS_PER_SEC / REPEITERA);
    printf("\t\t%f\n",              (tiempo_fin2-tiempo_ini2) /(double)CLOCKS_PER_SEC / REPERECUR);


    free(Matriz);
 }
 return 0;
}


// Definiciones de funciones
int rellena(int **M, int n){
 for(int i = 0; i < n; i++) {
   for(int j = 0; j < n; j++) {
     M[i][j] = rand();
   }
 }
}

int printMatriz(int **M, int n) { // método solo válido para matrices cuadradas (no se tiene m)
  for(int i = 0; i < n; i++) {
    for(int j = 0; j < n; j++) {
      printf("%d ", M[i][j]);
    }
    printf("\n");
  }

  return 0;
}

int rellenaNum(int **M, int n, int x) {
   for(int i = 0; i < n; i++) {
    for(int j = 0; j < n; j++) {
     M[i][j] = x; // VARIAR MAN. DEPENDIENDO DEL ALGORITMO
   }
 }
}

bool Busca(int **M, int n, int x) {
 int i = 0;
 bool encontrado = false;
 while(i < n && !encontrado) {
   i++;
   int j = 0;
   while(j < n && !encontrado) {
     j++;
     if(M[i-1][j-1] == x) encontrado = true;
   }
 }
 return encontrado;
}

int SumaIter(int**M, int n){
 int suma = 0;
 for(int i = 0; i < n; i++) {
   suma += M[i][i];
 }
 return suma;
}

int SumaRecur(int **M, int n){
 if(n == 0) return M[0][0];
 else {return M[n-1][n-1] + SumaRecur(M, n-1);}
}

