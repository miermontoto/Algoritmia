#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

# define NUM_TALLAS 10
# define REPEITERA 100000
# define REPERECUR 10000
# define REPEBUSCA 1000

// Prototipos de funciones
int   rellena(int **, int);
int  SumaIter(int **, int);
int SumaRecur(int **, int);
bool    Busca(int **, int, int);

// Programa principal
int main()
{
 int i,j;
 clock_t tiempo_ini1, tiempo_ini2, tiempo_fin1, tiempo_fin2;
 int talla[NUM_TALLAS]={1000,2000,3000,4000,5000,6000,7000,8000,9000,10000};
 int **Matriz=NULL, sumaiter=0, sumarecur=0;

 printf("\n\n   SESION 2 DE PRACTICAS DE ANALISIS DE ALGORITMOS  \n\n");
 printf("Tiempo empleado:\n\n\n");

 // ALUMNO: COMENTAR/DESCOMENTAR LOS SIGUIENTES printf EN FUNCION DE LAS MEDIDAS A REALIZAR

 printf("\t\tTalla\t\tTiempo Mejor caso\tTiempo Peor caso\n");
 printf("\t\t-----\t\t----------------\t----------------\n");

 printf("\t\tTalla\t\tTiempo Iterativo\tTiempo Recursivo\n");
 printf("\t\t-----\t\t----------------\t----------------\n");

 for (i=0;i<NUM_TALLAS;i++) {

    // ALUMNO: RESERVA DINAMICA DE MEMORIA PARA UNA MATRIZ CUADRADA DE talla[i] x talla[i] ENTEROS

    rellena(Matriz,talla[i]);

    // FRAGMENTO DE CODIGO PARA ANALIZAR LA BUSQUEDA EN LA MATRIZ

    tiempo_ini1=clock();
    for (j=1;j<=REPEBUSCA;j++)
      // ALUMNO: LLAMADA A LA FUNCION Busca
    tiempo_fin1=clock();

    tiempo_ini2=clock();
    for (j=1;j<=REPEBUSCA;j++)
      // ALUMNO: LLAMADA A LA FUNCION Busca
    tiempo_fin2=clock();

    printf("\t\t%d\t\t%f", talla[i],(tiempo_fin1-tiempo_ini1) /(double)CLOCKS_PER_SEC / REPEBUSCA);
    printf("\t\t%f\n",              (tiempo_fin2-tiempo_ini2) /(double)CLOCKS_PER_SEC / REPEBUSCA);

    // FRAGMENTO DE CODIGO PARA ANALIZAR LA SUMA DE LOS ELEMENTOS DE LA DIAGONAL DE LA MATRIZ

    tiempo_ini1=clock();
    for (j=1;j<=REPEITERA;j++)
      // ALUMNO: LLAMADA A LA FUNCION SumaIter, ESTA FUNCION TIENE QUE DEVOLVER EL RESULTADO
      // PARA COMPARARLO CON EL DE LA VERSION RECURSIVA
      // sumaiter = SumaIter(...);
    tiempo_fin1=clock();

    tiempo_ini2=clock();
    for (j=1;j<=REPERECUR;j++)
      // ALUMNO: LLAMADA A LA FUNCION SumaRecur, ESTA FUNCION TIENE QUE DEVOLVER EL RESULTADO
      // PARA COMPARARLO CON EL DE LA VERSION ITERATIVA
      // sumarecur = SumaRecur(...);
    tiempo_fin2=clock();

    if (sumarecur != sumaiter) { printf("Inconsistencia en las sumas\n\n"); return -1; }

    printf("\t\t%d\t\t%f", talla[i],(tiempo_fin1-tiempo_ini1) /(double)CLOCKS_PER_SEC / REPEITERA);
    printf("\t\t%f\n",              (tiempo_fin2-tiempo_ini2) /(double)CLOCKS_PER_SEC / REPERECUR);


    // ALUMNO: LIBERAR MEMORIA RESERVADA
 }
 return 0;
}


// Definiciones de funciones
int rellena(int **M, int n){
 // ALUMNO: DEFINICION DE LA FUNCION
}

bool Busca(int **M, int x, int n){
 // ALUMNO: DEFINICION DE LA FUNCION
}

int SumaIter(int**M, int n){
 // ALUMNO: DEFINICION DE LA FUNCION
}

int SumaRecur(int **M, int n){
 // ALUMNO: DEFINICION DE LA FUNCION
}

